import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

interface Branch {
  slNo: number;
  branchName: string;
  branchCode: string;
  state: string;
  country: string;
  contactPerson: string;
  panNo: string;
  gstNo: string;
  creditLimit: number;
  creditDays: number;
  paymentMode: string;
}

@Component({
  selector: 'app-origin-branch',
  templateUrl: './origin-branch.component.html',
  styleUrls: ['./origin-branch.component.css']
})
export class OriginBranchComponent implements OnInit {
  branchForm!: FormGroup;
  branches: Branch[] = [];
  countries = ['INDIA', 'USA', 'UK'];
  states = ['AGARTALA', 'AGRA', 'GUJARAT', 'ANDHRA PRADESH'];
  paymentModes = ['CASH', 'CREDIT', 'ONLINE'];

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.branchForm = this.fb.group({
      country: ['', Validators.required],
      branchName: ['', Validators.required],
      branchCode: ['', Validators.required],
      state: ['', Validators.required],
      contactNo: [''],
      email: ['', [Validators.email]],
      address: [''],
      prefix: [''],
      paymentMode: ['', Validators.required],
      contactPerson: [''],
      panNo: [''],
      gstNo: [''],
      creditLimit: [0],
      creditDays: [0],
      openingBalance: [0]
    });

    // Sample data
    this.branches = [
      { slNo: 1, branchName: 'AGARTALA', branchCode: '12363', state: 'AGARTALA', country: 'INDIA', contactPerson: 'Agartala', panNo: '---', gstNo: '', creditLimit: 0, creditDays: 0, paymentMode: 'CREDIT' },
      { slNo: 2, branchName: 'AGRA', branchCode: 'ARA', state: 'AGRA', country: 'INDIA', contactPerson: 'ARA', panNo: '---', gstNo: '', creditLimit: 0, creditDays: 0, paymentMode: 'CREDIT' }
    ];
  }

  onSave(): void {
    if (this.branchForm.valid) {
      const newBranch: Branch = {
        slNo: this.branches.length + 1,
        ...this.branchForm.value
      };
      this.branches.push(newBranch);
      this.branchForm.reset();
    }
  }

  onUpdate(): void {
    alert('Update functionality will be implemented');
  }

  onDelete(): void {
    alert('Delete functionality will be implemented');
  }

  onRefresh(): void {
    this.branchForm.reset();
  }

  onExport(): void {
    alert('Export functionality will be implemented');
  }

  onFileUpload(event: any): void {
    const file = event.target.files[0];
    if (file) {
      alert(`File uploaded: ${file.name}`);
    }
  }
}
