import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-awb-sales-entry',
  templateUrl: './awb-sales-entry.component.html',
  styleUrls: ['./awb-sales-entry.component.css']
})
export class AwbSalesEntryComponent {
  salesForm: FormGroup;
  salesEntries: any[] = [];
  showModal = false;

  constructor(private fb: FormBuilder) {
    this.salesForm = this.fb.group({
      invoiceNo: ['', Validators.required],
      customerName: ['', Validators.required],
      item: ['', Validators.required],
      quantity: [1, [Validators.required, Validators.min(1)]],
      price: [0, [Validators.required, Validators.min(0)]],
      date: ['', Validators.required]
    });
  }

  openModal() {
    this.showModal = true;
    this.salesForm.reset({
      quantity: 1,
      price: 0
    });
  }

  closeModal() {
    this.showModal = false;
  }

  saveEntry() {
    if (this.salesForm.valid) {
      this.salesEntries.push(this.salesForm.value);
      this.closeModal();
    }
  }

  deleteEntry(index: number) {
    this.salesEntries.splice(index, 1);
  }

  get totalAmount(): number {
    return this.salesEntries.reduce((sum, e) => sum + (e.quantity * e.price), 0);
  }
}
