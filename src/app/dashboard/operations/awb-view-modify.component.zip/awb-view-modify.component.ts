import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

type HoldStatus = 'unhold' | 'hold';

@Component({
  selector: 'app-awb-view-modify',
  templateUrl: './awb-view-modify.component.html',
  styleUrls: ['./awb-view-modify.component.css'],
})
export class AwbViewModifyComponent implements OnInit {
  form!: FormGroup;

  // Top nav (for highlighting if you wire routing later)
  activeTab: 'Master' | 'Operation' | 'Reports' = 'Operation';

  // Dropdown data
  paymentModes = ['Prepaid', 'Collect', 'Credit'];
  shipments = ['Shipper', 'Consignee', 'Third Party'];
  branches = ['BANGALORE', 'CHENNAI', 'MUMBAI', 'DELHI'];
  serviceTypes = ['DOMESTIC', 'INTERNATIONAL', 'PRIORITY', 'ECONOMY'];
  docTypes = ['DOCUMENT', 'NON-DOC', 'DOX', 'NDX'];
  currencies = ['INR', 'USD', 'EUR', 'AED', 'GBP'];
  itemTypes = ['General', 'Fragile', 'Perishable', 'High Value'];

  // Clock helpers
  hours: string[] = Array.from({ length: 12 }, (_, i) => (i + 1).toString().padStart(2, '0'));
  minutes: string[] = Array.from({ length: 60 }, (_, i) => i.toString().padStart(2, '0'));
  ampm = ['AM', 'PM'];

  // UI State
  awbMode: 'manual' | 'auto' = 'manual';
  holdStatus: HoldStatus = 'unhold';

  today = new Date();

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    const d = new Date();
    const hh = (d.getHours() % 12) || 12;
    const mm = d.getMinutes();
    const am = d.getHours() >= 12 ? 'PM' : 'AM';

    this.form = this.fb.group({
      header: this.fb.group({
        date: [this.toDateInput(d), Validators.required],
        hour: [hh.toString().padStart(2, '0'), Validators.required],
        min: [mm.toString().padStart(2, '0'), Validators.required],
        meridiem: [am, Validators.required],
        awbMode: ['manual'],
        awbNo: [''],
        autoAwbNo: [''],
        paymentMode: [this.paymentModes[0]],
        modeOfShipment: [this.shipments[0]],
        freightCharge: ['SHIPPER'],
        billingBranch: [this.branches[0]],
        billingClient: [''],
        destLocation: [''],
        serviceType: [this.serviceTypes[0]],
        docType: [this.docTypes[0]],
      }),

      shipper: this.fb.group({
        search: [''],
        name: ['', Validators.required],
        address1: [''],
        mobile: [''],
        pin: [''],
        city: [''],
        state: [''],
      }),

      consignee: this.fb.group({
        search: [''],
        name: ['', Validators.required],
        address1: [''],
        mobile: [''],
        pin: [''],
        city: [''],
        state: [''],
      }),

      summary: this.fb.group({
        totalPcs: [0, [Validators.min(0)]],
        totalWeight: [0, [Validators.min(0)]],
        currency: ['INR'],
      }),

      invoice: this.fb.group({
        invoiceValue: [0, [Validators.min(0)]],
        insurancePct: [0, [Validators.min(0)]],
        insuranceAmt: [{ value: 0, disabled: true }],
      }),

      billing: this.fb.group({
        chargeableWeight: [0, [Validators.min(0)]],
        freightAmt: [0, [Validators.min(0)]],
        fscAmt: [0, [Validators.min(0)]],
        cgst: [0, [Validators.min(0)]],
        sgst: [0, [Validators.min(0)]],
        igst: [0, [Validators.min(0)]],
        totalAmt: [{ value: 0, disabled: true }],
      }),

      cargo: this.fb.group({
        itemType: [this.itemTypes[0]],
        goodsDesc: [''],
        remarks: [''],
        holdStatus: ['unhold' as HoldStatus],
        holdReason: [''],
        fwdCourierName: [''],
        referenceNo: [''],
        fwdNo: [''],
      }),
    });

    // Auto calculations
    this.form.get('invoice.invoiceValue')!.valueChanges.subscribe(() => this.updateInsurance());
    this.form.get('invoice.insurancePct')!.valueChanges.subscribe(() => this.updateInsurance());

    ['billing.freightAmt', 'billing.fscAmt', 'billing.cgst', 'billing.sgst', 'billing.igst'].forEach(
      path => this.form.get(path)!.valueChanges.subscribe(() => this.updateTotal())
    );

    this.form.get('cargo.holdStatus')!.valueChanges.subscribe((v: HoldStatus) => (this.holdStatus = v));
    this.form.get('header.awbMode')!.valueChanges.subscribe((v: 'manual' | 'auto') => (this.awbMode = v));
  }

  // 🔑 Typed getters for template
  get headerForm(): FormGroup { return this.form.get('header') as FormGroup; }
  get shipperForm(): FormGroup { return this.form.get('shipper') as FormGroup; }
  get consigneeForm(): FormGroup { return this.form.get('consignee') as FormGroup; }
  get summaryForm(): FormGroup { return this.form.get('summary') as FormGroup; }
  get invoiceForm(): FormGroup { return this.form.get('invoice') as FormGroup; }
  get billingForm(): FormGroup { return this.form.get('billing') as FormGroup; }
  get cargoForm(): FormGroup { return this.form.get('cargo') as FormGroup; }

  // Helpers
  private toDateInput(d: Date): string {
    const yyyy = d.getFullYear();
    const mm = (d.getMonth() + 1).toString().padStart(2, '0');
    const dd = d.getDate().toString().padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  }

  updateInsurance(): void {
    const invoiceValue = Number(this.form.get('invoice.invoiceValue')!.value || 0);
    const pct = Number(this.form.get('invoice.insurancePct')!.value || 0);
    const amt = +(invoiceValue * (pct / 100)).toFixed(2);
    this.form.get('invoice.insuranceAmt')!.setValue(amt, { emitEvent: false });
  }

  updateTotal(): void {
    const f = Number(this.form.get('billing.freightAmt')!.value || 0);
    const fsc = Number(this.form.get('billing.fscAmt')!.value || 0);
    const cgst = Number(this.form.get('billing.cgst')!.value || 0);
    const sgst = Number(this.form.get('billing.sgst')!.value || 0);
    const igst = Number(this.form.get('billing.igst')!.value || 0);
    const total = +(f + fsc + cgst + sgst + igst).toFixed(2);
    this.form.get('billing.totalAmt')!.setValue(total, { emitEvent: false });
  }

  // Buttons
  onUpdate(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    console.log('UPDATE payload:', this.preparePayload());
    alert('AWB updated successfully (demo).');
  }

  onClear(): void {
    this.form.reset(this.form.getRawValue()); // reset with defaults
  }

  onPrint(): void { window.print(); }

  onAddCharge(): void {
    alert('Open "Add Charge" dialog (wire as needed).');
  }

  private preparePayload() {
    const raw = this.form.getRawValue();
    return {
      ...raw,
      invoice: { ...raw.invoice, insuranceAmt: this.form.get('invoice.insuranceAmt')!.value },
      billing: { ...raw.billing, totalAmt: this.form.get('billing.totalAmt')!.value },
    };
  }
}
