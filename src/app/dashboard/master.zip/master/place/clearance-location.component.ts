import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

interface ClearanceLocation {
  id: number;
  code: string;
  name: string;
  description?: string;
}

@Component({
  selector: 'app-clearance-location',
  templateUrl: './clearance-location.component.html',
  styleUrls: ['./clearance-location.component.css']
})
export class ClearanceLocationComponent implements OnInit {

  clearanceLocations: ClearanceLocation[] = [];
  clearanceForm!: FormGroup;
  isEditing: boolean = false;
  selectedId: number | null = null;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.clearanceForm = this.fb.group({
      code: ['', Validators.required],
      name: ['', Validators.required],
      description: ['']
    });

    // demo data (replace with API later)
    this.clearanceLocations = [
      { id: 1, code: 'CL001', name: 'Chennai Port', description: 'Main sea clearance' },
      { id: 2, code: 'CL002', name: 'Mumbai Airport', description: 'Air cargo clearance' }
    ];
  }

  onSubmit(): void {
    if (this.clearanceForm.invalid) return;

    if (this.isEditing && this.selectedId !== null) {
      const index = this.clearanceLocations.findIndex(c => c.id === this.selectedId);
      if (index > -1) {
        this.clearanceLocations[index] = {
          id: this.selectedId,
          ...this.clearanceForm.value
        };
      }
    } else {
      const newId = this.clearanceLocations.length
        ? Math.max(...this.clearanceLocations.map(c => c.id)) + 1
        : 1;
      this.clearanceLocations.push({
        id: newId,
        ...this.clearanceForm.value
      });
    }

    this.resetForm();
  }

  editLocation(location: ClearanceLocation): void {
    this.isEditing = true;
    this.selectedId = location.id;
    this.clearanceForm.patchValue(location);
  }

  deleteLocation(id: number): void {
    this.clearanceLocations = this.clearanceLocations.filter(c => c.id !== id);
    this.resetForm();
  }

  resetForm(): void {
    this.clearanceForm.reset();
    this.isEditing = false;
    this.selectedId = null;
  }
}
