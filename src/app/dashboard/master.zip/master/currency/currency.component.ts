// src/app/dashboard/master/currency/currency.component.ts
import { Component, OnInit } from '@angular/core';

interface Currency {
  id: number;
  code: string;
  name: string;
  symbol: string;
  active: boolean;
}

@Component({
  selector: 'app-currency',
  templateUrl: './currency.component.html',
  styleUrls: ['./currency.component.css']
})
export class CurrencyComponent implements OnInit {
  list: Currency[] = [];
  nextId = 1;

  model: Partial<Currency> = { code: '', name: '', symbol: '', active: true };
  editingId: number | null = null;
  search = '';

  ngOnInit(): void {
    this.list = [
      { id: this.nextId++, code: 'USD', name: 'US Dollar', symbol: '$', active: true },
      { id: this.nextId++, code: 'INR', name: 'Indian Rupee', symbol: '₹', active: true },
      { id: this.nextId++, code: 'EUR', name: 'Euro', symbol: '€', active: true },
    ];
  }

  save() {
    if (!this.model.code || !this.model.name) return;
    if (this.editingId != null) {
      const idx = this.list.findIndex(c => c.id === this.editingId);
      if (idx !== -1) {
        this.list[idx] = { id: this.editingId, code: this.model.code!, name: this.model.name!, symbol: this.model.symbol || '', active: !!this.model.active };
      }
      this.editingId = null;
    } else {
      this.list.push({ id: this.nextId++, code: this.model.code!, name: this.model.name!, symbol: this.model.symbol || '', active: !!this.model.active });
    }
    this.reset();
  }

  edit(c: Currency) {
    this.editingId = c.id;
    this.model = { ...c };
  }

  remove(c: Currency) {
    this.list = this.list.filter(x => x.id !== c.id);
    if (this.editingId === c.id) this.reset();
  }

  reset() {
    this.model = { code: '', name: '', symbol: '', active: true };
    this.editingId = null;
  }

  get filtered() {
    const q = this.search.trim().toLowerCase();
    if (!q) return this.list;
    return this.list.filter(c => c.code.toLowerCase().includes(q) || c.name.toLowerCase().includes(q) || (c.symbol || '').includes(q));
  }
}
