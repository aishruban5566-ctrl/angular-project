import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ReportsComponent } from './reports.component';
import { AwbSalesReportComponent } from './awb-sales-report.component';
import { AwbPrintReportComponent } from './awb-print-report.component';

const routes: Routes = [
  {
    path: '',
    component: ReportsComponent,
    children: [
      { path: 'sales', component: AwbSalesReportComponent },
      { path: 'print', component: AwbPrintReportComponent },
      { path: '', redirectTo: 'sales', pathMatch: 'full' }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule {}
