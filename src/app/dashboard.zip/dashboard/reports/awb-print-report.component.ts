import { Component } from '@angular/core';

@Component({
  selector: 'app-awb-print-report',
  templateUrl: './awb-print-report.component.html',
  styleUrls: ['./awb-print-report.component.css']
})
export class AwbPrintReportComponent {
  printOptions = {
    includeHeader: true
  };

  print() {
    // placeholder: implement print/export logic
    window.print();
  }
}
