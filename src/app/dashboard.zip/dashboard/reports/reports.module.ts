import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms'; // ✅ ADD THIS

import { ReportsComponent } from './reports.component';
import { AwbPrintReportComponent } from './awb-print-report.component';
import { AwbSalesReportComponent } from './awb-sales-report.component';
import { ReportsRoutingModule } from './reports-routing.module';

@NgModule({
  declarations: [
    ReportsComponent,
    AwbPrintReportComponent,
    AwbSalesReportComponent
  ],
  imports: [
    CommonModule,
    FormsModule,           // ✅ ADD THIS TOO
    ReportsRoutingModule,
    RouterModule
  ]
})
export class ReportsModule {}
