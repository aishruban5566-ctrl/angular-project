import { Component } from '@angular/core';

@Component({
  selector: 'app-awb-sales-report',
  templateUrl: './awb-sales-report.component.html',
  styleUrls: ['./awb-sales-report.component.css']
})
export class AwbSalesReportComponent {
  // Example placeholder data
  filters = {
    from: '',
    to: '',
    search: ''
  };

  // demo data
  rows = [
    { awb: '123-0001', date: '2025-08-01', value: 1200, customer: 'ABC' },
    { awb: '123-0002', date: '2025-08-02', value: 560, customer: 'XYZ' }
  ];

  applyFilters() {
    // placeholder: implement real filtering / API calls
    console.log('apply filters', this.filters);
  }
}
