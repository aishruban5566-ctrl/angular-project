import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

interface OriginBranch {
  id: number;
  branchCode: string;
  branchName: string;
  address?: string;
}

@Component({
  selector: 'app-origin-branch',
  templateUrl: './origin-branch.component.html',
  styleUrls: ['./origin-branch.component.css']
})
export class OriginBranchComponent implements OnInit {

  originBranches: OriginBranch[] = [];
  originBranchForm!: FormGroup;
  isEditing: boolean = false;
  selectedId: number | null = null;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.originBranchForm = this.fb.group({
      branchCode: ['', Validators.required],
      branchName: ['', Validators.required],
      address: ['']
    });

    // Demo Data
    this.originBranches = [
      { id: 1, branchCode: 'OB001', branchName: 'Chennai Main Branch', address: 'Guindy, Chennai' },
      { id: 2, branchCode: 'OB002', branchName: 'Delhi Main Branch', address: 'Connaught Place, Delhi' }
    ];
  }

  onSubmit(): void {
    if (this.originBranchForm.invalid) return;

    if (this.isEditing && this.selectedId !== null) {
      const index = this.originBranches.findIndex(b => b.id === this.selectedId);
      if (index > -1) {
        this.originBranches[index] = {
          id: this.selectedId,
          ...this.originBranchForm.value
        };
      }
    } else {
      const newId = this.originBranches.length
        ? Math.max(...this.originBranches.map(b => b.id)) + 1
        : 1;
      this.originBranches.push({
        id: newId,
        ...this.originBranchForm.value
      });
    }

    this.resetForm();
  }

  editBranch(branch: OriginBranch): void {
    this.isEditing = true;
    this.selectedId = branch.id;
    this.originBranchForm.patchValue(branch);
  }

  deleteBranch(id: number): void {
    this.originBranches = this.originBranches.filter(b => b.id !== id);
    this.resetForm();
  }

  resetForm(): void {
    this.originBranchForm.reset();
    this.isEditing = false;
    this.selectedId = null;
  }
}
