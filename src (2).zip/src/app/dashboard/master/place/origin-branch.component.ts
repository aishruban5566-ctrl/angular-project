import { Component } from '@angular/core';

@Component({
  selector: 'app-origin-branch',
  templateUrl: './origin-branch.component.html',
  styleUrls: ['./origin-branch.component.css']
})
export class OriginBranchComponent { }
