import { Component } from '@angular/core';

@Component({
  selector: 'app-place',
  templateUrl: './place.component.html',
  styleUrls: ['./place.component.css']
})
export class PlaceComponent {
  activeTab: string = 'clearance-location';

  setActiveTab(tab: string) {
    this.activeTab = tab;
  }
}
