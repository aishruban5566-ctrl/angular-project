declare module 'echarts' {
  const echarts: any;
  export default echarts;
  export type EChartsOption = any;
}
