import { Component } from '@angular/core';

@Component({
  selector: 'app-clearance-location',
  templateUrl: './clearance-location.component.html',
  styleUrls: ['./clearance-location.component.css']
})
export class ClearanceLocationComponent { }
