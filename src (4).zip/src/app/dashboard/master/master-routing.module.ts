import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MasterComponent } from './master.component';
import { PlaceComponent } from './place/place.component';
import { TariffComponent } from './tariff/tariff.component';
import { UnitOfMeasurementComponent } from './unit-of-measurement/unit-of-measurement.component';

const routes: Routes = [
  {
    path: '',
    component: MasterComponent,
    children: [
      { path: 'place', component: PlaceComponent },
      { path: 'tariff', component: TariffComponent },
      { path: 'unit-of-measurement', component: UnitOfMeasurementComponent },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MasterRoutingModule {}
