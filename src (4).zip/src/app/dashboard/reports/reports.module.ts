import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportsComponent } from './reports.component';
import { AwbPrintReportComponent } from './awb-print-report.component';
import { AwbSalesReportComponent } from './awb-sales-report.component';

import { ReportsRoutingModule } from './reports-routing.module';

@NgModule({
  declarations: [
    ReportsComponent,
    AwbPrintReportComponent,
    AwbSalesReportComponent,
  ],
  imports: [
    CommonModule,
    ReportsRoutingModule, // <-- important
  ],
})
export class ReportsModule {}
