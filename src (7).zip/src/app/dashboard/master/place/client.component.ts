import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

interface Client {
  id: number;
  clientCode: string;
  clientName: string;
  contactPerson?: string;
  email?: string;
}

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.css']
})
export class ClientComponent implements OnInit {

  clients: Client[] = [];
  clientForm!: FormGroup;
  isEditing: boolean = false;
  selectedId: number | null = null;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.clientForm = this.fb.group({
      clientCode: ['', Validators.required],
      clientName: ['', Validators.required],
      contactPerson: [''],
      email: ['', [Validators.email]]
    });

    // Demo data
    this.clients = [
      { id: 1, clientCode: 'C001', clientName: 'ABC Logistics', contactPerson: 'Ravi Kumar', email: 'ravi@abc.com' },
      { id: 2, clientCode: 'C002', clientName: 'Global Traders', contactPerson: 'Meena Patel', email: 'meena@global.com' }
    ];
  }

  onSubmit(): void {
    if (this.clientForm.invalid) return;

    if (this.isEditing && this.selectedId !== null) {
      const index = this.clients.findIndex(c => c.id === this.selectedId);
      if (index > -1) {
        this.clients[index] = {
          id: this.selectedId,
          ...this.clientForm.value
        };
      }
    } else {
      const newId = this.clients.length
        ? Math.max(...this.clients.map(c => c.id)) + 1
        : 1;
      this.clients.push({
        id: newId,
        ...this.clientForm.value
      });
    }

    this.resetForm();
  }

  editClient(client: Client): void {
    this.isEditing = true;
    this.selectedId = client.id;
    this.clientForm.patchValue(client);
  }

  deleteClient(id: number): void {
    this.clients = this.clients.filter(c => c.id !== id);
    this.resetForm();
  }

  resetForm(): void {
    this.clientForm.reset();
    this.isEditing = false;
    this.selectedId = null;
  }
}
