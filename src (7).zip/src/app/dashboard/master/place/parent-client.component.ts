import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

interface ParentClient {
  id: number;
  clientCode: string;
  clientName: string;
  contactPerson?: string;
  email?: string;
}

@Component({
  selector: 'app-parent-client',
  templateUrl: './parent-client.component.html',
  styleUrls: ['./parent-client.component.css']
})
export class ParentClientComponent implements OnInit {

  parentClients: ParentClient[] = [];
  parentClientForm!: FormGroup;
  isEditing: boolean = false;
  selectedId: number | null = null;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.parentClientForm = this.fb.group({
      clientCode: ['', Validators.required],
      clientName: ['', Validators.required],
      contactPerson: [''],
      email: ['', Validators.email]
    });

    // Demo Data
    this.parentClients = [
      { id: 1, clientCode: 'PC001', clientName: 'Tata Group', contactPerson: 'Ratan Tata', email: 'tata@example.com' },
      { id: 2, clientCode: 'PC002', clientName: 'Reliance Industries', contactPerson: 'Mukesh Ambani', email: 'reliance@example.com' }
    ];
  }

  onSubmit(): void {
    if (this.parentClientForm.invalid) return;

    if (this.isEditing && this.selectedId !== null) {
      const index = this.parentClients.findIndex(c => c.id === this.selectedId);
      if (index > -1) {
        this.parentClients[index] = {
          id: this.selectedId,
          ...this.parentClientForm.value
        };
      }
    } else {
      const newId = this.parentClients.length
        ? Math.max(...this.parentClients.map(c => c.id)) + 1
        : 1;
      this.parentClients.push({
        id: newId,
        ...this.parentClientForm.value
      });
    }

    this.resetForm();
  }

  editClient(client: ParentClient): void {
    this.isEditing = true;
    this.selectedId = client.id;
    this.parentClientForm.patchValue(client);
  }

  deleteClient(id: number): void {
    this.parentClients = this.parentClients.filter(c => c.id !== id);
    this.resetForm();
  }

  resetForm(): void {
    this.parentClientForm.reset();
    this.isEditing = false;
    this.selectedId = null;
  }
}
