import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

interface DeliveryState {
  id: number;
  stateCode: string;
  stateName: string;
  description?: string;
}

@Component({
  selector: 'app-delivery-state',
  templateUrl: './delivery-state.component.html',
  styleUrls: ['./delivery-state.component.css']
})
export class DeliveryStateComponent implements OnInit {

  deliveryStates: DeliveryState[] = [];
  stateForm!: FormGroup;
  isEditing: boolean = false;
  selectedId: number | null = null;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.stateForm = this.fb.group({
      stateCode: ['', Validators.required],
      stateName: ['', Validators.required],
      description: ['']
    });

    // Demo data
    this.deliveryStates = [
      { id: 1, stateCode: 'TN', stateName: 'Tamil Nadu', description: 'South India' },
      { id: 2, stateCode: 'MH', stateName: 'Maharashtra', description: 'West India' }
    ];
  }

  onSubmit(): void {
    if (this.stateForm.invalid) return;

    if (this.isEditing && this.selectedId !== null) {
      const index = this.deliveryStates.findIndex(s => s.id === this.selectedId);
      if (index > -1) {
        this.deliveryStates[index] = {
          id: this.selectedId,
          ...this.stateForm.value
        };
      }
    } else {
      const newId = this.deliveryStates.length
        ? Math.max(...this.deliveryStates.map(s => s.id)) + 1
        : 1;
      this.deliveryStates.push({
        id: newId,
        ...this.stateForm.value
      });
    }

    this.resetForm();
  }

  editState(state: DeliveryState): void {
    this.isEditing = true;
    this.selectedId = state.id;
    this.stateForm.patchValue(state);
  }

  deleteState(id: number): void {
    this.deliveryStates = this.deliveryStates.filter(s => s.id !== id);
    this.resetForm();
  }

  resetForm(): void {
    this.stateForm.reset();
    this.isEditing = false;
    this.selectedId = null;
  }
}
