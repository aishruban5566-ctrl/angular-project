import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

interface ClearancePart {
  id: number;
  partCode: string;
  partName: string;
  description?: string;
}

@Component({
  selector: 'app-clearance-part',
  templateUrl: './clearance-part.component.html',
  styleUrls: ['./clearance-part.component.css']
})
export class ClearancePartComponent implements OnInit {

  parts: ClearancePart[] = [];
  partForm!: FormGroup;
  isEditing: boolean = false;
  selectedId: number | null = null;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.partForm = this.fb.group({
      partCode: ['', Validators.required],
      partName: ['', Validators.required],
      description: ['']
    });

    // Demo data
    this.parts = [
      { id: 1, partCode: 'P001', partName: 'Invoice Copy', description: 'Document required for clearance' },
      { id: 2, partCode: 'P002', partName: 'Packing List', description: 'List of packed goods' }
    ];
  }

  onSubmit(): void {
    if (this.partForm.invalid) return;

    if (this.isEditing && this.selectedId !== null) {
      const index = this.parts.findIndex(p => p.id === this.selectedId);
      if (index > -1) {
        this.parts[index] = {
          id: this.selectedId,
          ...this.partForm.value
        };
      }
    } else {
      const newId = this.parts.length
        ? Math.max(...this.parts.map(p => p.id)) + 1
        : 1;
      this.parts.push({
        id: newId,
        ...this.partForm.value
      });
    }

    this.resetForm();
  }

  editPart(part: ClearancePart): void {
    this.isEditing = true;
    this.selectedId = part.id;
    this.partForm.patchValue(part);
  }

  deletePart(id: number): void {
    this.parts = this.parts.filter(p => p.id !== id);
    this.resetForm();
  }

  resetForm(): void {
    this.partForm.reset();
    this.isEditing = false;
    this.selectedId = null;
  }
}
