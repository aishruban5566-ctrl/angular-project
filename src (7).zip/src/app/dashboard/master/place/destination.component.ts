import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

interface Destination {
  id: number;
  destinationCode: string;
  destinationName: string;
  description?: string;
}

@Component({
  selector: 'app-destination',
  templateUrl: './destination.component.html',
  styleUrls: ['./destination.component.css']
})
export class DestinationComponent implements OnInit {

  destinations: Destination[] = [];
  destinationForm!: FormGroup;
  isEditing: boolean = false;
  selectedId: number | null = null;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.destinationForm = this.fb.group({
      destinationCode: ['', Validators.required],
      destinationName: ['', Validators.required],
      description: ['']
    });

    // Demo data
    this.destinations = [
      { id: 1, destinationCode: 'DST001', destinationName: 'Chennai Warehouse', description: 'South Zone Hub' },
      { id: 2, destinationCode: 'DST002', destinationName: 'Delhi Hub', description: 'North Zone Hub' }
    ];
  }

  onSubmit(): void {
    if (this.destinationForm.invalid) return;

    if (this.isEditing && this.selectedId !== null) {
      const index = this.destinations.findIndex(d => d.id === this.selectedId);
      if (index > -1) {
        this.destinations[index] = {
          id: this.selectedId,
          ...this.destinationForm.value
        };
      }
    } else {
      const newId = this.destinations.length
        ? Math.max(...this.destinations.map(d => d.id)) + 1
        : 1;
      this.destinations.push({
        id: newId,
        ...this.destinationForm.value
      });
    }

    this.resetForm();
  }

  editDestination(destination: Destination): void {
    this.isEditing = true;
    this.selectedId = destination.id;
    this.destinationForm.patchValue(destination);
  }

  deleteDestination(id: number): void {
    this.destinations = this.destinations.filter(d => d.id !== id);
    this.resetForm();
  }

  resetForm(): void {
    this.destinationForm.reset();
    this.isEditing = false;
    this.selectedId = null;
  }
}
