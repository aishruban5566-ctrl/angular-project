import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

interface Country {
  id: number;
  countryCode: string;
  countryName: string;
  description?: string;
}

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.css']
})
export class CountryComponent implements OnInit {

  countries: Country[] = [];
  countryForm!: FormGroup;
  isEditing: boolean = false;
  selectedId: number | null = null;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.countryForm = this.fb.group({
      countryCode: ['', Validators.required],
      countryName: ['', Validators.required],
      description: ['']
    });

    // Demo data
    this.countries = [
      { id: 1, countryCode: 'IN', countryName: 'India', description: 'South Asia' },
      { id: 2, countryCode: 'US', countryName: 'United States', description: 'North America' }
    ];
  }

  onSubmit(): void {
    if (this.countryForm.invalid) return;

    if (this.isEditing && this.selectedId !== null) {
      const index = this.countries.findIndex(c => c.id === this.selectedId);
      if (index > -1) {
        this.countries[index] = {
          id: this.selectedId,
          ...this.countryForm.value
        };
      }
    } else {
      const newId = this.countries.length
        ? Math.max(...this.countries.map(c => c.id)) + 1
        : 1;
      this.countries.push({
        id: newId,
        ...this.countryForm.value
      });
    }

    this.resetForm();
  }

  editCountry(country: Country): void {
    this.isEditing = true;
    this.selectedId = country.id;
    this.countryForm.patchValue(country);
  }

  deleteCountry(id: number): void {
    this.countries = this.countries.filter(c => c.id !== id);
    this.resetForm();
  }

  resetForm(): void {
    this.countryForm.reset();
    this.isEditing = false;
    this.selectedId = null;
  }
}
