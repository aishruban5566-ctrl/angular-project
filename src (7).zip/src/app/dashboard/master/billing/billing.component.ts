// src/app/dashboard/master/billing/billing.component.ts
import { Component, OnInit } from '@angular/core';

interface BillingRecord {
  id: number;
  name: string;
  chargeType: string;
  amount: number;
  currency: string;
  active: boolean;
}

@Component({
  selector: 'app-billing',
  templateUrl: './billing.component.html',
  styleUrls: ['./billing.component.css']
})
export class BillingComponent implements OnInit {
  billingList: BillingRecord[] = [];
  nextId = 1;

  // simple form model
  model: Partial<BillingRecord> = {
    name: '',
    chargeType: '',
    amount: null,
    currency: 'USD',
    active: true
  };

  // UI state
  editingId: number | null = null;
  filterText = '';

  ngOnInit(): void {
    // seed with sample data
    this.billingList = [
      { id: this.nextId++, name: 'Freight Charge', chargeType: 'Weight', amount: 120.50, currency: 'USD', active: true },
      { id: this.nextId++, name: 'Customs Fee', chargeType: 'Flat', amount: 35.00, currency: 'USD', active: true },
      { id: this.nextId++, name: 'Fuel Surcharge', chargeType: 'Percentage', amount: 5.0, currency: 'USD', active: false },
    ];
  }

  addOrUpdate() {
    if (!this.model.name || this.model.amount == null) return;

    if (this.editingId != null) {
      // update
      const idx = this.billingList.findIndex(b => b.id === this.editingId);
      if (idx !== -1) {
        this.billingList[idx] = {
          id: this.editingId,
          name: this.model.name,
          chargeType: this.model.chargeType || 'N/A',
          amount: Number(this.model.amount),
          currency: this.model.currency || 'USD',
          active: !!this.model.active
        };
      }
      this.editingId = null;
    } else {
      // add
      this.billingList.push({
        id: this.nextId++,
        name: this.model.name,
        chargeType: this.model.chargeType || 'N/A',
        amount: Number(this.model.amount),
        currency: this.model.currency || 'USD',
        active: !!this.model.active
      });
    }

    this.resetForm();
  }

  edit(item: BillingRecord) {
    this.editingId = item.id;
    this.model = { ...item };
  }

  delete(item: BillingRecord) {
    this.billingList = this.billingList.filter(b => b.id !== item.id);
    if (this.editingId === item.id) this.resetForm();
  }

  resetForm() {
    this.model = { name: '', chargeType: '', amount: null, currency: 'USD', active: true };
    this.editingId = null;
  }

  toggleActive(item: BillingRecord) {
    item.active = !item.active;
  }

  get filteredList() {
    const q = (this.filterText || '').toLowerCase().trim();
    if (!q) return this.billingList;
    return this.billingList.filter(b =>
      b.name.toLowerCase().includes(q) ||
      b.chargeType.toLowerCase().includes(q) ||
      String(b.amount).includes(q) ||
      b.currency.toLowerCase().includes(q)
    );
  }
}
